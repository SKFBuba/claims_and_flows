#### Filter baci data and prepare for export

## data was downloaded here: http://www.cepii.fr/CEPII/en/bdd_modele/download.asp?id=37
## bundesbank system couldnt dowload it. why?
## version: HS02

# Variable 	Description
# t 	Year
# k 	Product category (HS 6-digit code)
# i 	Exporter (ISO 3-digit country code)
# j 	Importer (ISO 3-digit country code)
# v 	Value of the trade flow (in thousands current USD)
# q 	Quantity (in metric tons)


library(data.table)
library(tidyverse)

#### import ####
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) # set wd to source file location
source("helpers.R")

files <- list.files(pattern = "*.csv")
df_list <- lapply(files, fread, na.string = "N/A")

#### perpare data ####
convert <- function(x){
  x[, q:=NULL] # remove quantity in tons or ...
  x[, v:=sum(v, na.rm=T), by = .(t,i,j)] # aggregate over products
  x[, k:=NULL] # remove product code
  x <- unique(x) # remove duplicates
  gc()
  return(x)
}

df_list <- lapply(df_list, convert)

out <- bind_rows(df_list)

#### merge country codes #### 
codes <- fread("documentation/country_codes_V202102.csv")
codes <- codes[,c("country_code", "iso_2digit_alpha")]

# exporter
out <- left_join(out, codes, by = c("i"="country_code"))
out[, iso_2digit_alpha:=na_if(x=iso_2digit_alpha,y=c("N/A"))]
out[, iso_2digit_alpha:=na_if(x=iso_2digit_alpha,y=c(""))]
sum(is.na(out[, iso_2digit_alpha]))
out[i==516, iso_2digit_alpha:="NA"] # Namibia
out[i==849, iso_2digit_alpha:="PU"] # United States Miscellaneous Pacific Islands
unique(out[is.na(iso_2digit_alpha),i])
out[,i:=NULL]
names(out)[which(names(out)=="iso_2digit_alpha")] <- "i"

# importer
out <- left_join(out, codes, by = c("j"="country_code"))
out[, iso_2digit_alpha:=na_if(x=iso_2digit_alpha,y=c("N/A"))]
out[, iso_2digit_alpha:=na_if(x=iso_2digit_alpha,y=c(""))]
sum(is.na(out[, iso_2digit_alpha]))
out[j==516, iso_2digit_alpha:="NA"] # Namibia
out[j==849, iso_2digit_alpha:="PU"] # United States Miscellaneous Pacific Islands
unique(out[is.na(iso_2digit_alpha),j])
out[,j:=NULL]
names(out)[which(names(out)=="iso_2digit_alpha")] <- "j"

setcolorder(out, c("t", "i", "j", "v"))

# transfer from thousands to normal values
out[, v := v*1000]

fwrite(out, "baci_total exports.csv")
