## (fast) helper functions

#### data table manuipulation ####
# create lags
lagger <- function(df, nr_lags, date_column = 1, content = 2, return_date = TRUE){
  df <- as.data.frame(df)
  stock <- names(df)[content]
  
  lags <- matrix(NA, nrow(df), nr_lags)
  names <- matrix(NA,nr_lags,1)
  for (i in 1:nr_lags){
    end <- nrow(df)-i
    lags[,i] <- c(rep(NA,i),df[1:end,content])
    names[i,1] <- paste0(stock, "_lag_", i)
  }
  lags <- data.frame(df[,date_column], lags)
  names(lags) <- c("Date",names)
  lags <- as.data.table(lags, key = names(lags)[date_column])
  
  if(return_date == TRUE){
    return(lags)
  } else {
    return(lags[,-..date_column])
  }
}

na_fill <- function(x, include=NULL, bys,direction = "downup", as_df = FALSE){
  setDT(x)
  
  if(is.null(include)){
    include <- names(x)
    include <- include[include %!in% bys]
  }
  
  if(direction=="downup"){
    for (i in include){
      col_tmp <- i
      nas <- x[, sum(is.na(.SD)),  .SDcols = which(names(x)==col_tmp)]
      
      if(nas>0){
        x[, (col_tmp) := na.locf(eval(as.name(col_tmp)), na.rm=F), by = .(eval(as.name(bys)))][]
        nas <- x[, sum(is.na(.SD)),  .SDcols = which(names(x)==col_tmp)]
        if(nas>0){
          x[, (col_tmp) := na.locf(eval(as.name(col_tmp)), fromLast=T), by = .(eval(as.name(bys)))][]
        }
      }
    }
  }
  
  if(direction=="updown"){
    for (i in include){
      col_tmp <- i
      nas <- x[, sum(is.na(.SD)),  .SDcols = which(names(x)==col_tmp)]
      
      if(nas>0){
        x[, (col_tmp) := na.locf(eval(as.name(col_tmp)), fromLast=T), by = .(eval(as.name(bys)))][]
        nas <- x[, sum(is.na(.SD)),  .SDcols = which(names(x)==col_tmp)]
        if(nas>0){
          x[, (col_tmp) := na.locf(eval(as.name(col_tmp)), na.rm=T), by = .(eval(as.name(bys)))][]
        }
      }
    }
  }
  
  if(direction=="down"){
    for (i in include){
      col_tmp <- i
      nas <- x[, sum(is.na(.SD)),  .SDcols = which(names(x)==col_tmp)]
      
      if(nas>0){
        x[, (col_tmp) := na.locf(eval(as.name(col_tmp)), fromLast=T), by = .(eval(as.name(bys)))][]
      }
    }
  }
  
  if(direction=="up"){
    for (i in include){
      col_tmp <- i
      nas <- x[, sum(is.na(.SD)),  .SDcols = which(names(x)==col_tmp)]
      
      if(nas>0){
        x[, (col_tmp) := na.locf(eval(as.name(col_tmp)), na.rm=F), by = .(eval(as.name(bys)))][]
      }
    }
  }
  
  if(as_df==TRUE){
    x <- as.data.frame(x)
  }
  return(x)
}

# difference data table function
fast_diff <- function(x, include=NULL, bys, as_df = FALSE){
  setDT(x)
  
  x[, unique_group_identifier:= .GRP, by = .(eval(as.name(bys)))]
  
  if(is.null(include)){
    include <- names(x)
    include <- include[include %!in% c(bys, "unique_group_identifier")]
  }

  for (i in include){
    col_tmp <- i
    x[, (col_tmp) := c(NA,diff(eval(as.name(col_tmp)))), by = unique_group_identifier]
    #x[, (col_tmp) := (eval(as.name(col_tmp)) - shift(eval(as.name(col_tmp)))), by = .(eval(as.name(bys)))]
  }
  
  if(as_df==TRUE){
    x <- as.data.frame(x)
  }
  return(x)
}

# not in function
'%!in%' <- function(x,y)!('%in%'(x,y))

## fast merge
# source: https://rstudio-pubs-static.s3.amazonaws.com/52230_5ae0d25125b544caab32f75f0360e775.html
#' merge list of data frames fast
#' @list input list of data frames
#' @key variable to merge on, must be character, can be one for each frame or only one name if it is the same for all variables
#' @as_df default FALSE; if true returns data.frame instead of data.table 
merge_list <- function(list, key, type, as_df = FALSE){
  list <- lapply(list, as.data.table)
  
  # define key to merge on variable
  if(length(key) <= 1){
    key <- rep(key[1], length(list))
  }
  
  d1 <- list[[1]]
  d2 <- data.table()
  setkeyv(d1, key[1])
  
  # dt merge produces weird column order --> keep original order through names
  col_order <- names(d1)
  
  if(type == 'inner'){
    for (i in 2:length(list)){
      d2 <- list[[i]]
      setkeyv(d2, key[i])
      names2 <- names(d2)
      names2 <- names2[which(names2 != key[i])] # avoid duplicates in column order
      col_order <- c(col_order, names2)
      
      d1 <- d1[d2, nomatch = 0]
      setkeyv(d1, key[1])
    } 
  } else if (type == 'left') {
    
    for (i in 2:length(list)){
      d2 <- list[[i]]
      setkeyv(d2, key[i])
      names2 <- names(d2)
      names2 <- names2[which(names2 != key[i])] # avoid duplicates in column order
      col_order <- c(col_order, names2)
      
      d1 <- d2[d1]
      setkeyv(d1, key[1])
    } 
  } else if (type == 'right') {
    
    for (i in 2:length(list)){
      d2 <- list[[i]]
      setkeyv(d2, key[i])
      names2 <- names(d2)
      names2 <- names2[which(names2 != key[i])] # avoid duplicates in column order
      col_order <- c(col_order, names2)
      
      d1 <- d1[d2]
      setkeyv(d1, key[1])
    } 
  } else if (type == 'outer') {
    
    for (i in 2:length(list)){
      d2 <- list[[i]]
      names2 <- names(d2)
      names2 <- names2[which(names2 != key[i])] # avoid duplicates in column order
      col_order <- c(col_order, names2)
      
      names2[which(names2 == key[i])] <- key[1] 
      
      d1 <- full_join(d1, d2, by = key[1])
      d1 <- as.data.table(d1)
      setkeyv(d1, key[1])
    } 
  }
  setcolorder(d1, col_order)
  
  if(as_df == TRUE){
    d1 <- as.data.frame(d1)
  }
  
  return(d1)
}


na_replace <- function(x, value=0, include=NULL, exclude=NULL, as_df=FALSE){
  
  setDT(x)
  
  if(is.null(include)){
    include <- names(x)
  }
  
  if(!is.null(exclude)){
    include <- include[include %!in% exclude]
  }
  
  for (i in include) {
    x[is.na(get(i)), (i):=value]
  }
  if(as_df==TRUE){
    x <- as.data.frame(x)
  }
  return(x)
}



#### plots ####
multi_line_plot <- function(df, date_col = 1, exclude = NULL, save = NULL,
                            x_lab = '', y_lab = '', title = '',
                            legend = TRUE, width = 6, height = 3, add_points = FALSE){
  # remove columns to be excluded
  df <- as.data.frame(df)
  if(!is.null(exclude)){
    df <- df[,-exclude]
  }
  
  # convert to long
  df_long <- df %>% pivot_longer(-(date_col), names_to ='name',values_to = 'value')
  
  # start plot
  plot <- ggplot(df_long, aes(x = eval(as.name(names(df)[date_col])), y = value, color = name, linetype = name)) 
  
  if(add_points == TRUE){
    plot <- ggplot(df_long, aes(x = eval(as.name(names(df)[date_col])), y = value, color = name, shape = name)) + 
      geom_point(size = 2)
  }
  
  plot <- plot + geom_line(size = 1)
  
  ## labels
  plot <- plot + xlab(x_lab) + ylab(y_lab) + ggtitle(title) +
    scale_color_viridis_d(option = 'magma', end = 0.75) + 
    theme_minimal(base_family = 'serif') + 
    theme(legend.title=element_blank(), plot.title = element_text(hjust = 0.5))
  
  if(add_points == TRUE){
    plot <- plot +  scale_shape_manual(values = (1:(ncol(df)-1)))
  } else{
    plot <- plot +  scale_linetype_manual(values = (1:(ncol(df)-1)))
  }
  
  ## extra options
  if(legend == FALSE){
    plot <- plot + theme(legend.position = "none")
  }
  
  if(!is.null(save)){
    pdf(file = save, width = width, height = height)
    plot
    print(plot)
    dev.off()
    print(paste('saved plot in', save))
  }
  
  return(plot)
}
# number of observations
give.n <- function(x){
  return(c(y = if_else(IQR(x)<=0.1, 0.5, mean(fivenum(x)[3:4])), label = length(x)))
}

box_plot <- function(df, date_col, id_col, year=NULL, include = NULL, replace_zeros=TRUE,
                            show_n=TRUE,save = NULL, x_lab = '', y_lab = '', title = '',
                            legend = FALSE, width = 6, height = 3){
  df <- as.data.frame(df)
  
  # convert to long
  df_long <- pivot_longer(df, cols= -c(date_col, id_col), names_to ='name',values_to = 'value')
  
  
  # filter to keep only relevant
  if(!is.null(include)){
    df_long <- df_long %>% filter(name %in% include)
  }
  
  # aggregate and filter year
  if(!is.null(year)){
    df_long <- df_long %>% filter(date == year)
  }
  
  if(replace_zeros==TRUE){
    df_long <- na_if(df_long, 0)
  }
  
  # start plot
  plot <- ggplot(df_long, aes(x = name, y = value, fill=name)) +
    geom_boxplot()
  if(show_n==TRUE){
    plot <- plot + stat_summary(fun.data = give.n, geom = "text", size =3)
                
  }
  
  ## labels and design
  plot <- plot + xlab(x_lab) + ylab(y_lab) + ggtitle(title) +
    scale_fill_viridis(discrete = TRUE, alpha=0.6, option="magma") + 
    theme_minimal(base_family = 'serif') + 
    theme(legend.title=element_blank(), plot.title = element_text(hjust = 0.5))
  
  ## extra options
  if(legend == FALSE){
    plot <- plot + theme(legend.position = "none")
  }
  
  if(!is.null(save)){
    pdf(file = save, width = width, height = height)
    plot
    print(plot)
    dev.off()
    print(paste('saved plot in', save))
  }
  
  return(plot)
}


box_plot_time <- function(df, date_col, id_col, value = NULL, replace_zeros=TRUE,
                     show_n=TRUE,save = NULL, x_lab = '', y_lab = '', title = '',
                     legend = FALSE, width = 6, height = 3){
  df <- as.data.frame(df)
  
  if(is.character(value)){
    value <- which(names(df)==value)
  }
  
  names(df)[date_col] <- "date"
  names(df)[value] <- "value"
  
  if(!is.null(replace_zeros)){
    df <- na_if(df, 0)
  }
  
  # start plot
  plot <- ggplot(df, aes(x = date, y = value, group = date)) +
    geom_boxplot()
  if(show_n==TRUE){
    plot <- plot + stat_summary(fun.data = give.n, geom = "text", size =3)
    
  }
  
  ## labels and design
  plot <- plot + xlab(x_lab) + ylab(y_lab) + ggtitle(title) +
    scale_fill_viridis(discrete = TRUE, alpha=0.6, option="magma") + 
    theme_minimal(base_family = 'serif') + 
    theme(legend.title=element_blank(), plot.title = element_text(hjust = 0.5))
  
  ## extra options
  if(legend == FALSE){
    plot <- plot + theme(legend.position = "none")
  }
  
  if(!is.null(save)){
    pdf(file = save, width = width, height = height)
    plot
    print(plot)
    dev.off()
    print(paste('saved plot in', save))
  }
  
  return(plot)
}


#box_plot_time(df_model, date_col = 1, id_col = which(names(df)=="id"), value="growth")

get_legend<-function(myggplot){
  tmp <- ggplot_gtable(ggplot_build(myggplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)
}

## stakced bar plot
bar_plot_stacked <- function(df, x_col, group_col, val_col,
                     show_n=TRUE,save = NULL, x_lab = '', y_lab = '', title = '',dodge=FALSE,
                     legend = FALSE, l.position="right",width = 6, height = 3, colour= "brewer"){
  df <- as.data.frame(df)
  names(df)[x_col] <- "x"
  names(df)[group_col] <- "group"
  names(df)[val_col] <- "value"
  
  # start plot
  if(n_distinct(df$x)==1){
    plot <- ggplot(df, aes(x = x, y = value, fill=group)) +
      geom_bar(position="stack", stat="identity", width=1) # set witdth for only one column    
  } else {
    plot <- ggplot(df, aes(x = x, y = value, fill=group)) +
      geom_bar(position="stack", stat="identity")
  }
  
  if(dodge==TRUE){
    plot <- ggplot(df, aes(x = x, y = value, fill=group)) +
      geom_bar(position="dodge", stat="identity")
  }
  
  if(show_n==TRUE){
    plot <- plot + stat_summary(fun.data = give.n, geom = "text", size =3)
    
  }
  
  ## labels and design
  if(colour=="brewer"){
    if(n_distinct(df[,group_col])>11){ # epand colour palette
      nb.cols <- n_distinct(df[,group_col]) # number of groups
      mycolors <- colorRampPalette(brewer.pal(11, "Spectral"))(nb.cols)
      
      
      plot <- plot + xlab(x_lab) + ylab(y_lab) + ggtitle(title) +
        scale_fill_manual(values = mycolors) + 
        #scale_fill_viridis(discrete = TRUE, alpha=1, option="turbo")
        theme_minimal(base_family = 'serif') + 
        theme(legend.title=element_blank(), plot.title = element_text(hjust = 0.5),
	legend.position="right", legend.box = "vertical", legend.key.size = unit(0.2, "cm"),
	legend.text = element_text(size = 8)) #move legend to bottom, if too many groups
    } else{
      plot <- plot + xlab(x_lab) + ylab(y_lab) + ggtitle(title) +
        scale_fill_brewer(palette = "Spectral") + 
        #scale_fill_viridis(discrete = TRUE, alpha=1, option="turbo")
        theme_minimal(base_family = 'serif') + 
        theme(legend.title=element_blank(), plot.title = element_text(hjust = 0.5))
    }
  } else if(colour=="R") {
    plot <- plot + xlab(x_lab) + ylab(y_lab) + ggtitle(title) +
      theme_minimal(base_family = 'serif') + 
      theme(legend.title=element_blank(), plot.title = element_text(hjust = 0.5))
  }
  ## extra options
  if(legend == FALSE){
    plot <- plot + theme(legend.position = "none")
  }
  
  if(!is.null(save)){
    pdf(file = save, width = width, height = height)
    plot
    print(plot)
    dev.off()
    print(paste('saved plot in', save))
  }
  
  return(plot)
}

#### simple stats ####

#' function to compare differences in means by country and year
panel_two_sided <- function(df, id_col1,id_col2, groups, groups_col, mean_col, type="t"){
  if(length(groups)!=2){
    message("test only works for two groups")
  }
  
  # convert cols to number if string
  if(typeof(id_col1)=="character") {id_col1=which(names(df)==id_col1)}
  if(typeof(id_col2)=="character") {id_col2=which(names(df)==id_col2)}
  if(typeof(groups_col)=="character") {groups_col=which(names(df)==groups_col)}
  if(typeof(mean_col)=="character") {mean_col=which(names(df)==mean_col)}
  
  # create one data frame for sd an mean separetly
  df <- as.data.frame(df)
  means <- df[ ,c(id_col1, id_col2, groups_col, mean_col)]
  
  id_col1 <- 1
  id_col2 <- 2
  groups_col <- 3
  mean_col <- 4
  
  names(means) <- c("id1", "id2", "group",  "data")
  means <- means %>% filter(!is.na(data))
  
  # convert to wide
  means <- means %>% 
    pivot_wider(names_from = group, values_from = data)
  names(means) <- c("id1", "id2", "value1", "value2")
  
  # na handling
  means <- means[!is.na(means[,3]) & !is.na(means[,3]),]
  means[is.na(means)] <- 0
  
  ## compute stats for each id
  n <- n_distinct(means[, id_col2])
  ids <- as.matrix(unique(means[, id_col2]))
  out <- matrix(NA, nrow=n, ncol = 3)
  
  for (i in 1:n){
    # filter for id group
    tmp <- means %>% filter(id2==ids[i,1])
    tmp <- as.data.frame(tmp)

    x <- as.numeric(as.matrix(tmp[,3]))
    y <-  as.numeric(as.matrix(tmp[,4]))
    
    if (type == "t"){
      test <- t.test(x, y, alternative = "two.sided", var.equal = F)
    } else if (type == "wilcox"){
      test <- wilcox.test(x, y, alternative = "two.sided")
      test$estimate[1] <- mean(x)
      test$estimate[2] <- mean(y)
    }
    
    out[i,1] <- ids[i]
    out[i,2] <- test$estimate[2] - test$estimate[1] # difference in means
    out[i,3] <- test$p.value
    
  }
  out <- as.data.frame(out)
  names(out) <- c("Country", "Difference", "P-Value")
  return(out)
}


#' creates summary stats for sub samples of panel data
#' sample is divided into four groups, pre nontreat, pre treat, post non_treat, post nontreat
#' @diff_in_means if TRUE performs diff in means test between treated and non treated
#' @include_diff_in_means requires an option, whether and how to include the
#' diff in means test. "both" includes summary in test, "only" prints only diff in means
#' if diff in means == FALSE, no diff in means is computed and reported

panel_summary <- function(df, time_dummy, treat_dummy, include, 
                          diff_in_means=TRUE,include_diff_in_means="both",
                          as_df=FALSE){
  setDT(df)
  
  ## four groups: pre nontreat, pre treat, post non_treat, post nontreat
  df[, group1:=ifelse((eval(as.name(time_dummy))==0 & eval(as.name(treat_dummy))==0), 1, 0)]
  df[, group2:=ifelse((eval(as.name(time_dummy))==0 & eval(as.name(treat_dummy))==1), 1, 0)]
  df[, group3:=ifelse((eval(as.name(time_dummy))==1 & eval(as.name(treat_dummy))==0), 1, 0)]
  df[, group4:=ifelse((eval(as.name(time_dummy))==1 & eval(as.name(treat_dummy))==1), 1, 0)]
  
  out_pre <- matrix(NA, nrow=length(include), ncol=13)
  out_post <- out_pre
  
  for (i in include){
    # pre non-treat
    out_pre[which(include==i),1] <- i
    out_pre[which(include==i),2] <- mean(df[group1==1, eval(as.name(i))], na.rm=T)
    out_pre[which(include==i),3] <- median(df[group1==1, eval(as.name(i))], na.rm=T)
    out_pre[which(include==i),4] <- sd(df[group1==1, eval(as.name(i))], na.rm=T)
    out_pre[which(include==i),5] <- min_na(df[group1==1, eval(as.name(i))])
    out_pre[which(include==i),6] <- max_na(df[group1==1, eval(as.name(i))])
    out_pre[which(include==i),7] <- nrow(df[group1==1 & !is.na(eval(as.name(i))), ])
    
    # pre treat
    out_pre[which(include==i),8] <- mean(df[group2==1, eval(as.name(i))], na.rm=T)
    out_pre[which(include==i),9] <- median(df[group2==1, eval(as.name(i))], na.rm=T)
    out_pre[which(include==i),10] <- sd(df[group2==1, eval(as.name(i))], na.rm=T)
    out_pre[which(include==i),11] <- min_na(df[group2==1, eval(as.name(i))])
    out_pre[which(include==i),12] <- max_na(df[group2==1, eval(as.name(i))])
    out_pre[which(include==i),13] <- nrow(df[group2==1 & !is.na(eval(as.name(i))), ])
    
    # post non-treat
    out_post[which(include==i),1] <- i
    out_post[which(include==i),2] <- mean(df[group3==1, eval(as.name(i))], na.rm=T)
    out_post[which(include==i),3] <- median(df[group3==1, eval(as.name(i))], na.rm=T)
    out_post[which(include==i),4] <- sd(df[group3==1, eval(as.name(i))], na.rm=T)
    out_post[which(include==i),5] <- min_na(df[group3==1, eval(as.name(i))])
    out_post[which(include==i),6] <- max_na(df[group3==1, eval(as.name(i))])
    out_post[which(include==i),7] <- nrow(df[group3==1 & !is.na(eval(as.name(i))), ])
    
    # post treat
    out_post[which(include==i),8] <- mean(df[group4==1, eval(as.name(i))], na.rm=T)
    out_post[which(include==i),9] <- median(df[group4==1, eval(as.name(i))], na.rm=T)
    out_post[which(include==i),10] <- sd(df[group4==1, eval(as.name(i))], na.rm=T)
    out_post[which(include==i),11] <- min_na(df[group4==1, eval(as.name(i))])
    out_post[which(include==i),12] <- max_na(df[group4==1, eval(as.name(i))])
    out_post[which(include==i),13] <- nrow(df[group4==1 & !is.na(eval(as.name(i))), ])
  }
  
  out_pre <- as.data.frame(out_pre)
  out_post <- as.data.frame(out_post)
  out_pre[,2:ncol(out_pre)] <- apply(out_pre[,2:ncol(out_pre)], 2, as.numeric)
  out_post[,2:ncol(out_post)] <- apply(out_post[,2:ncol(out_post)], 2, as.numeric)
  
  col_names <- c("Variable", "Mean nt", "Median nt", "Sd. nt", "Min. nt", "Max nt", "N nt",
                 "Mean t", "Median t", "Sd. t", "Min. t", "Max t", "N t")
  names(out_pre) <- col_names
  names(out_post) <- col_names
  
  ## diff in means
  ## source http://www.stat.yale.edu/Courses/1997-98/101/meancomp.htm
  if(diff_in_means==TRUE){
    dim_pre <- matrix(NA,nrow=length(include), ncol=3)
    dim_post <- dim_pre
    
    dim_pre[,1] <- out_pre[,8] - out_pre[,2]
    dim_pre[,2] <- (out_pre[,8] - out_pre[,2]) / sqrt(((out_pre[,4]/out_pre[,7]) + (out_pre[,10]/out_pre[,13])))
    dim_pre[,3] <- (1-pt(abs(dim_pre[,2]), df=(apply(out_pre[, c(7,13)], 1, min))-1))*2
    
    dim_post[,1] <- out_post[,8] - out_post[,2]
    dim_post[,2] <- (out_post[,8] - out_post[,2]) / sqrt(((out_post[,4]/out_post[,7]) + (out_post[,10]/out_post[,13])))
    dim_post[,3] <- (1-pt(abs(dim_post[,2]), df=(apply(out_post[, c(7,13)], 1, min))-1))*2
    
    dim_pre <- as.data.frame(dim_pre)
    dim_post <- as.data.frame(dim_post)
    
    names(dim_pre) <- c("Diff.", "T-stat", "p-value")
    names(dim_post) <- names(dim_pre)
    
    dim_pre <- apply(dim_pre,2,as.numeric)
    dim_post <- apply(dim_post,2,as.numeric)
    
    if(include_diff_in_means=="both"){
      out_pre <- cbind(out_pre, dim_pre)
      out_post <- cbind(out_post, dim_post)
    } else if(include_diff_in_means=="only"){
      out_pre <- as.data.frame(cbind(out_pre[,1], dim_pre))
      out_post <- as.data.frame(cbind(out_post[,1], dim_post))
    }
    
  }
  
  out_pre[,2:ncol(out_pre)] <- apply(out_pre[,2:ncol(out_pre)], 2, as.numeric)
  out_post[,2:ncol(out_post)] <- apply(out_post[,2:ncol(out_post)], 2, as.numeric)
  
  if(as_df==FALSE){
    setDT(out_pre)
    setDT(out_post)
  }
  
  return(list(pre=out_pre, post=out_post))
}
#test <- panel_summary(trade, time_dummy = "post", treat_dummy = "treat", include = c("dist_km", "Euros"))


#### other ####
to_formula <- function(outcome, variables){
  formula <- as.formula(paste(outcome, 
                        paste(variables, collcollapse = " + "),
                        sep = " ~ "))
  return(formula)
}

max_na <- function(x){
  x <- sort(x, na.last=F)
  
  x <- x[length(x)] 
  return(x)
}

min_na <- function(x){
  x <- sort(x, na.last=T)
  
  x <- x[1] 
  return(x)
}

